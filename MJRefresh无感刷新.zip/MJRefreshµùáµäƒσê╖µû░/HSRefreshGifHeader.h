//
//  RefreshGifHeader.h
//  JunyouPlat
//
//  Created by Junyou on 2022/3/16.
//

#import "MJRefreshGifHeader.h"

NS_ASSUME_NONNULL_BEGIN

@interface HSRefreshGifHeader : MJRefreshGifHeader


@end

NS_ASSUME_NONNULL_END
