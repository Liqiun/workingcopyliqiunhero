//
//  HSWuGanRefreshFooter.m
//  HSPublicModule
//
//  Created by 袁灿 on 2022/7/8.
//  Copyright © 2022 yuancan. All rights reserved.
//

#import "HSWuGanRefreshFooter.h"

@interface HSWuGanRefreshFooter ()

@end

@implementation HSWuGanRefreshFooter

#pragma mark - 实现父类的方法
- (void)prepare {
    [super prepare];
}

- (void)placeSubviews{
    [super placeSubviews];
    
    self.stateLabel.hidden = self.state != MJRefreshStateNoMoreData;
 
}

- (void)scrollViewContentSizeDidChange:(NSDictionary *)change
{
    [super scrollViewContentSizeDidChange:change];
    
    // 内容的高度
    CGFloat contentHeight = self.scrollView.mj_contentH + self.ignoredScrollViewContentInsetBottom;
    // 表格的高度
    CGFloat scrollHeight = self.scrollView.mj_h - self.scrollViewOriginalInset.top - self.scrollViewOriginalInset.bottom + self.ignoredScrollViewContentInsetBottom;
    // 设置位置和尺寸
    self.mj_y = MAX(contentHeight, scrollHeight);
    
}


@end
