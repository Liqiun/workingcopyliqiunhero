//
//  HSWuGanRefreshFooter.h
//  HSPublicModule
//
//  Created by 袁灿 on 2022/7/8.
//  Copyright © 2022 yuancan. All rights reserved.
//

#import "BaseTableViewController.h"
#import "MJRefreshAutoStateFooter.h"


NS_ASSUME_NONNULL_BEGIN

@interface HSWuGanRefreshFooter : MJRefreshAutoStateFooter

@end

NS_ASSUME_NONNULL_END
